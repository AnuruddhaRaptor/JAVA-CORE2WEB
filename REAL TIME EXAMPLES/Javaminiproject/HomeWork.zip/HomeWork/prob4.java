package HomeWork;

public class prob4 {
    public static void main(String[] args) {
        int[] arr = {7, 25, 5, 19, 30};
        int num1 = Integer.parseInt(args[0]);
        int num2 = Integer.parseInt(args[1]);
        boolean found = false;

        System.out.println("Your first number was " + num1);
        System.out.println("Your second number was " + num2);

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == num1 || arr[i] == num2) {
                found = true;
                break;
            }
        }

        if (found) {
            System.out.println("Its Bingo!");
        } else {
            System.out.println("Not Found!");
        }

        System.out.print("The array was ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}

