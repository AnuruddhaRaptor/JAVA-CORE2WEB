package HomeWork;

class General extends Compartment{

	public void notice() {
        System.out.println("Welcome to the General compartment");
    }
	
}
