package HomeWork;

class Flute extends Instrument {

	public void play() {
        System.out.println("Flute is playing toot toot toot toot");
    }
}
