package HomeWork;
import java.util.Random;

public class TestCompartment {

	public static void main(String[] args) {
		
	
		Random rand = new Random();
    
		Compartment[] compartments = new Compartment[10];
	
		//compartments[10] = new Compartment();
    
		for (int i = 0; i < 10; i++) {
			int randNum = rand.nextInt(4) + 1; // Generate random number between 1 to 4
			switch (randNum) {
            	case 1:
            		compartments[i] = new FirstClass();
            		break;
            	case 2:
            		compartments[i] = new Ladies();
            		break;
            	case 3:
            		compartments[i] = new General();
            		break;
            	case 4:
            		compartments[i] = new Luggage();
            		break;
			}	
        compartments[i].notice(); // polymorphic behavior
    }
}
}
