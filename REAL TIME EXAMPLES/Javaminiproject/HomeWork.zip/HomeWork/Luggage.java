package HomeWork;

class Luggage extends Compartment{

	 public void notice() {
	        System.out.println("Welcome to the Luggage compartment");
	    }
}
