package HomeWork;

class Ladies extends Compartment{

	public void notice() {
        System.out.println("Welcome to the Ladies compartment");
    }
}
