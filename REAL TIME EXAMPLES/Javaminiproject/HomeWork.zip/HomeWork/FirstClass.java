package HomeWork;

class FirstClass extends Compartment{

	 public void notice() {
	        System.out.println("Welcome to the First Class compartment");
	    }
}
