package HomeWork;

abstract class Instrument {

	public abstract void play();
}
