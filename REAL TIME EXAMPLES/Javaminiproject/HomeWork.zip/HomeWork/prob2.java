package HomeWork;

public class prob2 {

	public static void main(String[] args) {

		int num1 = Integer.parseInt(args[0]);
        int num2 = Integer.parseInt(args[1]);

        System.out.print(num1 + " " + num2 + " ");
        
        for (int i = 0; i < 13; i++) {
            int sum = num1 + num2;
            System.out.print(sum + " ");
            num1 = num2;
            num2 = sum;
        }
    }
}
